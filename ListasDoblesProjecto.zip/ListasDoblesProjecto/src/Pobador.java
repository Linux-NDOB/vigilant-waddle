import javax.swing.*;

public class Pobador {

    public static void main(String args[]){
        Lista miLista =new Lista();
        int op;
        String mat;
        do{
            op=Integer.parseInt(JOptionPane.showInputDialog(
                    "Menú Principal \n"+
                            "1. Agregar nodo al final \n"+
                            "2. Agregar nodo al comienzo \n"+
                            "3. Buscar por registro de niño \n"+
                            "4. Buscar por id de padre \n"+
                            "5. Eliminar un niño y su representante por registro \n"+
                            "6. Niños bajos de talla \n"+
                            "7. Niños bajos de peso \n"+
                            "8. Niños por cada municipio \n"+
                            "9. Guardar lista \n"+
                            "10. Salir \n"+
                            "Entre su opción: ?"
            ));

            switch(op){
                case 1:
                    miLista.addfinal();
                    break;
                case 2:
                    miLista.inicio();
                    break;
                case 3:
                    int registro = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el registro a buscar"));
                    miLista.registroCivil(registro);
                    break;
                case 4:
                    int idPadre = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el id del padre a buscar"));
                    miLista.xPadre(idPadre);
                    break;

                case 5:
                     registro = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el registro a eliminar"));
                    miLista.eliminar(registro);
                    break;

                case 8:
                    miLista.lorica();
                    miLista.monteria();
                    miLista.sahagun();
                    break;

                case 9:
                    miLista.guardar();
                    break;




                case 10:
                    JOptionPane.showMessageDialog(null, "Adios!!!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null,
                            "Error!!! Opción invalida.");
            }

        }while(op!=10);
        System.exit(0);
    }
}
