import javax.swing.*;

public class nodo {

    public int  idPadre;

    public String nombrePabre;

    public int registro;

    public String nombre;

    public int talla;

    public int peso;

    public int edad;

    public String municipio;

    nodo sig , ant = null;

    public nodo() {
        idPadre = -1;
        nombrePabre = "";
        registro = -1;
        nombre = "";
        talla = -1;
        peso = -1;
        edad = -1;
        municipio = "";
    }

    public nodo(int idPadre, String nombrePabre,
                int registro, String nombre, int talla,
                int peso, int edad, String municipio) {
        this.idPadre = idPadre;
        this.nombrePabre = nombrePabre;
        this.registro = registro;
        this.nombre = nombre;
        this.talla = talla;
        this.peso = peso;
        this.edad = edad;
        this.municipio = municipio;

        sig = ant = null;
    }

    public void tallaYPeso(){

        String a = "La talla y el peso del niño son : \n";

        a += "Talla : " + talla + "\n";

        a += "Peso: " + peso + "\n";

        JOptionPane.showMessageDialog(null, a);
    }

    public void mostrar(){

        String a = "Informacion del niño y representante : \n";

        a += "Id de representante: " + idPadre+ "\n";

        a += "Nombre representante: " + nombrePabre + "\n";

        a += "Registro civil : " + registro + "\n";

        a += "Nombre : " + nombre + "\n";

        a += "Edad: " + edad + "\n";

        a += "Talla: " + talla + "\n";

        a += "Peso: " + peso + "\n";
        JOptionPane.showMessageDialog(null, a);
    }
}
