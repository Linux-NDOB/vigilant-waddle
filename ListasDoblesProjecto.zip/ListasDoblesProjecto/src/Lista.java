import javax.swing.*;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Lista {

    nodo cab;

    Lista(){

        cab=null;

    }

    public nodo ultimo(){

        if(cab==null)

            return null;

        else{

            nodo q = cab;

            while(q.sig!=null)

                q=q.sig;

            return q;

        }
    }

    public nodo registro(int registro){

        if(cab == null)

            return null;

        else{

            nodo n = cab;

            while(n != null){

                if(n.registro == registro)

                    return n;

                n=n.sig;

            }

            return null;
        }
    }


    public nodo padre(int idPadre){

        if(cab == null)

            return null;

        else{

            nodo n = ultimo();

            while(n != null){

                if(n.idPadre == idPadre)

                    return n;

                n=n.ant;

            }

            return null;
        }
    }




    public nodo crear(){

        nodo inf = null, n = null , x = null;

         int  idPadre;

         String nombrePabre;

         int registro;

         String nombre;

         int talla;

         int peso;

         int edad;

         String municipio;

         int cLorica = 0;

        int cMont = 0 ;

        int cSa = 0;

        int contParent = 0;

        int contCLH = 0;

        int contCLW = 0;


        Object tyMun [] = new Object[]{"Lorica","Sahagún" , "Montería"};

        Object xMun = JOptionPane.showInputDialog(null,
                "Please choose the Municipality",
                "Municipality Selection",
                JOptionPane.QUESTION_MESSAGE,null,tyMun ,tyMun[0]);

        municipio = xMun.toString();

        if (municipio.equals("Lorica"))
            cLorica++;

        else  if (municipio.equals("Sahagún"))
            cSa++;

        else if (municipio.equals("Montería"))
            cMont++;
        nombre = JOptionPane.showInputDialog("Ingrese nombre del niño");

        do {

            registro = Integer.parseInt(JOptionPane.showInputDialog
                    ("Entre registro civil del niño: "));

            n = registro(registro);

            if(n!=null)
                JOptionPane.showMessageDialog(null,
                        "Error! el registro civil es unico.");

        }while(n!=null);

        talla = Integer.parseInt(JOptionPane.showInputDialog("Ingrese talla del niño (cm)"));

        peso =  Integer.parseInt(JOptionPane.showInputDialog("Ingrese peso del niño (Kg)"));

        do{

            edad = Integer.parseInt(JOptionPane.showInputDialog("Entre edad del niño"));

            if(edad > 6)
                JOptionPane.showMessageDialog
                        (null,"Error!la edad no puede ser mayor que 6 años");



        }while( edad > 6  || edad < 1);

        nombrePabre = JOptionPane.showInputDialog("Ingrese nombre de padre");
        do{

            idPadre = Integer.parseInt(JOptionPane.showInputDialog("Ingrese id de padre"));

            x = padre(idPadre);

            if (x != null)
                contCLH++;

            if (contCLH > 2)
                JOptionPane.showMessageDialog(null,"PAriente solo puede representar 2");


        }while ( contCLH > 2);






        inf = new nodo( idPadre,nombrePabre,registro,nombre,talla,peso,edad,municipio);
       return inf;

    }


    public void addfinal(){

        nodo inf = crear();

        if(cab==null){

            cab = inf;

            JOptionPane.showMessageDialog(null,
                    "Añadido, lista estaba vacia");

        }else{

            nodo u=ultimo();

            u.sig = inf;

            inf.ant=u;

            JOptionPane.showMessageDialog(null,
                    "Añadido al final");

        }
    }

    public void inicio () {

        nodo inf = crear();

        if (cab == null) {

            cab = inf;

            JOptionPane.showMessageDialog(null,
                    "Añadido, lista estaba vacia");

        } else {

            inf.sig = cab;

            cab.ant = inf;

            cab = inf; //cab=cab.ant;

            JOptionPane.showMessageDialog(null,
                    "Añadido al inicio");

        }
    }



    public void registroCivil(int registro){

        nodo b= registro(registro);

        if(cab == null)

            JOptionPane.showMessageDialog(null,
                    "Empty List ");

        else if(b==null)

            JOptionPane.showMessageDialog(null,
                    "The searched element is not here");

        else

            b.tallaYPeso();
    }


    public void xPadre(int idPadre){

        nodo b= padre(idPadre);

        if(cab == null)

            JOptionPane.showMessageDialog(null,
                    "Empty List");

        else if(b==null)

            JOptionPane.showMessageDialog(null,
                    "The searched element is not here");

        else

            b.tallaYPeso();
    }





    public void eliminar(int registro){

        if(cab == null)

            JOptionPane.showMessageDialog(null,
                    "Lista vacia");

        else{

            nodo b= registro(registro);

            if(b==null)

                JOptionPane.showMessageDialog(null,
                        "No se encuentra el elemento");

            else{

                if((b == cab)&&(cab.foll == null)){

                    cab=null;

                    JOptionPane.showMessageDialog(null,
                            "eLiminado el unico elemento de la lista");
                }

                else if((b == cab)&&(cab.sig != null)){

                    cab=cab.sig;

                    b.sig=null;

                    cab.ant=null;

                    b=null;

                    JOptionPane.showMessageDialog(null,
                            "Eliminado al inicio de la lsita");

                }

                else if(b.sig==null){

                    b.ant.sig=null;

                    b.ant=null;

                    b=null;

                    JOptionPane.showMessageDialog(null,
                            "Eliminado al final de la lista");
                }
                else{

                    b.ant.sig=b.ant;

                    b.sig.ant=b.ant;

                    b.ant=b.sig=null;

                    b=null;

                    JOptionPane.showMessageDialog(null,
                            "Eliminado entre 2 nodos");
                }
            }
        }
    }


    void guardar(){

        FileWriter fichero = null;

        PrintWriter pw = null;

        if(cab == null){

            try{

                fichero = new FileWriter("c:/Prueba/prueba.txt");

                pw = new PrintWriter(fichero);

                pw.println("Lista vacia");

                JOptionPane.showMessageDialog(
                        null, "Datos guardados al archivo!",
                        "Información",
                        JOptionPane.INFORMATION_MESSAGE);

            }catch (Exception e) {

                JOptionPane.showMessageDialog(
                        null, "Informacion: \n"+e.getMessage(),
                        "Error!",
                        JOptionPane.WARNING_MESSAGE);

            } finally {

                try {

                    //Aprovechamos el finally para
                    //asegurarnos que se cierra el fichero.
                    if (null != fichero)
                        fichero.close();

                } catch (Exception e2) {

                    JOptionPane.showMessageDialog(
                            null, "Informacion: \n"+e2.getMessage(),
                            "Error!",
                            JOptionPane.WARNING_MESSAGE);

                }
            }

        }else{

            try{

                fichero = new FileWriter("c:/Prueba/prueba.txt");

                pw = new PrintWriter(fichero);

                nodo p= cab;

                while(p!=null){

                    pw.println(""+p.idPadre);

                    pw.println(""+p.nombrePabre);

                    pw.println(""+p.registro);

                    pw.println(""+p.nombre);

                    pw.println(""+p.talla);

                    pw.println(""+p.peso);

                    pw.println(""+p.edad);

                    pw.println(""+p.municipio);



                    p=p.sig;

                }

                JOptionPane.showMessageDialog(
                        null, "Datos guardados al archivo!",
                        "Información",
                        JOptionPane.INFORMATION_MESSAGE);

            }catch (Exception e) {

                JOptionPane.showMessageDialog(
                        null, "Informacion: \n"+e.getMessage(),
                        "Error!",
                        JOptionPane.WARNING_MESSAGE);

            } finally {

                try {

                    //Aprovechamos el finally para
                    //asegurarnos que se cierra el fichero.
                    if (null != fichero)
                        fichero.close();

                } catch (Exception e2) {

                    JOptionPane.showMessageDialog(
                            null, "Informacion: \n"+e2.getMessage(),
                            "Error!",
                            JOptionPane.WARNING_MESSAGE);

                }
            }
        }
    }

    public  nod childLH(){



        if(head == null){

            JOptionPane.showMessageDialog(null,"Empty list");

            return null;

        }
        else{

            JOptionPane.showMessageDialog(null,"Information about the boys with LH :"+" \n"+

                    "Children with CL in Lorica : " + cLHL() +"\n"+

                    "Children with CL in Montería : " + cLHM() +" \n"+

                    "Children with CL in Sahagún : " + cLHS() +" \n");

        }


        JOptionPane.showMessageDialog(null,"Empty list");

        return null;
    }




    public  void childLW(){

        JOptionPane.showMessageDialog(null,
                "Information about the boys with LH : "+"\n"+

                        "Children with CL in Lorica : " + cLWL() +"\n"+

                        "Children with CL in Montería : " + cLWM() +"\n"+

                        "Children with CL in Sahagún : " + cLWS() +"\n");


    }

    public  void municipality(){

        nod n = getLast();

        JOptionPane.showMessageDialog(null,
                "The Information about the boys in each municipality is :" + "\n" +

                        "Children  in Lorica : " + n.L() +  "\n" +

                        "Children  in Montería : " + n.M() + "\n" +

                        "Children  in Sahagún : " + n.S() + "\n");

    }

    public int cLHL(){

        int c = 0;

        if(head == null)

            return 0;

        else{

            nod n = getLast();

            while(n != null){

                if (n.municipality.equals("Lorica") && n.childAge >= 4 && n.childAge <= 6 && n.childHeight < 100)

                    c++;



                n=n.bef;

                return c;

            }

            return 0;
        }
    }

    public int cLHS(){

        int c = 0;

        if(head == null)

            return 0;

        else{

            nod n = getLast();

            while(n != null){

                if (n.municipality.equals("Sahagún") && n.childAge >= 4 && n.childAge <= 6 && n.childHeight < 100)
                    c++;




                n=n.bef;




                return c;



            }

            return 0;
        }
    }

    public int cLHM(){

        int c = 0;

        if(head == null)

            return 0;

        else{

            nod n = getLast();

            while(n != null){

                if (n.municipality.equals("Montería") && n.childAge >= 4 && n.childAge <= 6 && n.childHeight < 100)

                    c++;



                n=n.bef;

                return c;



            }

            return 0;


        }
    }

    public int cLWL(){

        int c = 0;

        if(head == null)

            return 0;

        else{

            nod n = getLast();

            while(n != null){

                if (n.municipality.equals("Lorica")  && n.childAge == 2 || n.childAge == 3 && n.childWeight < 15)

                    c++;


                n=n.bef;

                return c;

            }

            return 0;
        }
    }

    public int cLWS(){

        int c = 0;

        if(head == null)

            return 0;

        else{

            nod n = getLast();

            while(n != null){

                if (n.municipality.equals("Sahagún")  && n.childAge == 2 || n.childAge == 3 && n.childWeight < 15)
                    c++;


                n=n.bef;




                return c;



            }

            return 0;
        }
    }

    public int cLWM(){

        int c = 0;

        if(head == null)

            return 0;

        else{

            nod n = getLast();

            while(n != null){

                if (n.municipality.equals("Montería")  && n.childAge >= 2 && n.childAge <
                        3 && n.childWeight < 15)

                    c++;

                n=n.bef;

                return c;



            }

            return 0;


        }
    }

    public nod childLw() {

        if (head == null){

            JOptionPane.showMessageDialog(null, "Nothing here");
            return null;

        }else {

            nod n = getLast();

            while (n != null) {

                if (((n.childAge >= 2 && n.childAge <= 3) && (n.childWeight < 15)))

                    n.showAll();


                n = n.bef;

            }

            JOptionPane.showMessageDialog(null, "Nothing here");

            return null;

        }
    }


    public nodo lorica(){
         int c = 0;
        if(cab == null){

            JOptionPane.showMessageDialog(null, "Ningun niño registrado");

            return null;

        }else{

            nodo n = cab;

            while(n != null){



                if (n.municipio.equals("Lorica")) {

                    n.mostrar();
                    c++;
                }
                    JOptionPane.showMessageDialog(null, " Cantidad de niños en lorica : " + c);






                n=n.sig;

            }
            JOptionPane.showMessageDialog(null, "No encontrado ");

            return null;
        }
    }

    public nodo monteria(){
        int c = 0;
        if(cab == null){JOptionPane.showMessageDialog(null, "Ningun niño registrado");return null;}



        else{

            nodo n = cab;

            while(n != null){



                if ( n.municipio.equals("Montería")) {

                    n.mostrar();
                    c++;
                }
                JOptionPane.showMessageDialog(null, " Cantidad de niños en monteria : " + c);

                n=n.sig;

            }

            JOptionPane.showMessageDialog(null, "No encontrado");

            return null;
        }
    }

    public nodo sahagun(){
       int c = 0;
        if(cab == null){
            JOptionPane.showMessageDialog(null, "Ningun niño registrado");
            return null;}



        else{

            nodo n = cab;

            while(n != null){

                if ( n.municipio.equals("Sahagún")) {

                    n.mostrar();
                    c++;
                }
                  JOptionPane.showMessageDialog(null, " Cantidad de niños en sahagun : " + c);

                n=n.sig;

            }

            JOptionPane.showMessageDialog(null, "No encontrado");

            return null;
        }
    }

    public void bajaTalla(){
        nodo q = getnodoant();
        int contS = 0, contM = 0, contL = 0;
        String InfoS = "", InfoM = "", InfoL = "";
        while(q!=null){
            if((q.edad>=4 && q.edad<=6)){
                if(q.estatura<1)
                    if(q.Municipio.equals("Sahagún")){
                        contS++;
                        InfoS += "\nNombre: "+q.Nombre+" \n Edad: "+q.edad+"  \nAltura: "+q.estatura;
                    }
                    else{
                        if(q.Municipio.equals("Montería")){
                            contM++;
                            InfoM += "\nNombre: "+q.Nombre+"  \nEdad: "+q.edad+" \n Altura: "+q.estatura;
                        }else{
                            if(q.Municipio.equals("Lorica")){
                                contL++;
                                InfoL += "\nNombre: "+q.Nombre+"  \nAge: "+q.edad+"  \nAltura: "+q.estatura;
                            }
                        }
                    }
            }
            q=q.ant;
        }
        JOptionPane.showMessageDialog(null, "Niños con menores tamaños. \n\nSahagún: "+contS+"\nMontería: "+contM+"\nLorica: "+contL+
                "\n\nSahagún.\n"+InfoS+"\n\nMontería.\n"+InfoM+"\n\nLorica.\n"+InfoL);

    }
    public void bajoPeso(){
        nodo p = cab;

        int contS = 0, contM = 0, contL = 0;

        String InfoS = "", InfoM = "", InfoL = "";

        while(p!=null){
            if((p.edad>=2 && p.edad<=3)){
                if(p.peso<15)
                    if(p.municipio.equals("Sahagún")){
                        contS++;
                        InfoS += "\nNombre: "+p.nombre+" ,\n Edad: "+p.edad+"  \nPeso: "+p.peso;
                    }
                    else{
                        if(p.municipio.equals("Montería")){
                            contM++;
                            InfoM += "\nNombre: "+p.nombre+" \n Edad: "+p.edad+"  \nPeso: "+p.peso;
                        }else{
                            if(p.municipio.equals("Lorica")){
                                contL++;
                                InfoL += "\nNombre: "+p.nombre+"  \nEdad: "+p.edad+"  \nPeso: "+p.peso;
                            }
                        }
                    }
            }
            p=p.sig;
        }
        JOptionPane.showMessageDialog(
                null, "Niños con peso bajo. \n\n" +
                        "Sahagún: "+contS+
                        "\nMontería: "+contM+
                        "\nLorica: "+contL+
                        "\n\nSahagún.\n"+InfoS+
                        "\n\nMontería.\n"+InfoM+"\n\nLorica.\n"+InfoL);
    }

}
